package com.bankuserservice.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bankuserservice.demo.dao.IBankAccount;
import com.bankuserservice.demo.dao.IBankuser;
import com.bankuserservice.demo.entity.User;
import com.bankuserservice.demo.model.UserBo;

@RestController
public class BankUserCotroller {

	@Autowired
	private IBankuser bankUserRepo;

	@Autowired
	private IBankAccount account;

	@GetMapping("/getAllUser")
	public List<User> findAllUser() {
		return bankUserRepo.findAll();
	}

	@PostMapping("/addUser")
	public User addUser(@RequestBody UserBo request) {
		return bankUserRepo.save(request.getUser());
	}

	@PutMapping("/updateUser")
	public User updateUser(@RequestBody UserBo request) {
		User user = new User();
		Boolean isExist = bankUserRepo.existsById(request.getUser().getUserId());
		if (isExist) {
			bankUserRepo.delete(request.getUser());
			user = bankUserRepo.save(request.getUser());
		}
		return user;
	}

	@DeleteMapping("/deleteUser")
	public void deleteUser(@RequestBody UserBo request) {

		Boolean isExist = bankUserRepo.existsById(request.getUser().getUserId());
		if (isExist) {
			bankUserRepo.delete(request.getUser());
		}
	}
}
