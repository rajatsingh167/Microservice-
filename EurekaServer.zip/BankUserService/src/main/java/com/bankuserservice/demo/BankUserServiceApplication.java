package com.bankuserservice.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;


@EnableEurekaClient
@SpringBootApplication
public class BankUserServiceApplication {

	public static void main(String[] args) {
		//System.setProperty("spring.datasource.url","jdbc:h2:tcp://localhost:9091/mem:mydb");
		SpringApplication.run(BankUserServiceApplication.class, args);
	}

}
