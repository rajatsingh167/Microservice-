package com.bankuserservicerest.demo;

import java.sql.SQLException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.h2.tools.Server;

@SpringBootApplication
@ComponentScan("com.bankuserservicerest.demo")
public class BankUserServiceRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankUserServiceRestApplication.class, args);
	}

	@Bean(initMethod = "start", destroyMethod = "stop")
	public Server inMemoryH2DatabaseaServer() throws SQLException {
	    return Server.createTcpServer("-tcp", "-tcpAllowOthers", "-tcpPort", "9090");
	}
}
