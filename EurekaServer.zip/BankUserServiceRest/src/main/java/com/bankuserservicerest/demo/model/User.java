package com.bankuserservicerest.demo.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class User implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "USER_ID")
	String userId;

	@Column(name = "FIRST_NAME", length = 100)
	String firstName;

	@Column(name = "LAST_NAME", length = 100)
	String lastName;

	@Column(name = "EMAIL", length = 100)
	String email;

	@Column(name = "PHONENO", length = 100)
	String phoneNo;

	@Column(name = "ADDRESS1", length = 300)
	String address1;

	@Column(name = "ADDRESS2", length = 300)
	String address2;

	@OneToMany(targetEntity = Account.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "USERACCOUNT_FK", referencedColumnName = "USER_ID")
	List<Account> account;

	public User(String phoneNo, String address1, String address2, List<Account> account2) {
		this.phoneNo = phoneNo;
		this.address1 = address1;
		this.address2 = address2;
		this.account = account2;

	}

	public User() {

	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public List<Account> getAccount() {
		return account;
	}

	public void setAccount(List<Account> account) {
		this.account = account;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", phoneNo=" + phoneNo + ", address1=" + address1 + ", address2=" + address2 + ", account=" + account
				+ "]";
	}

}
