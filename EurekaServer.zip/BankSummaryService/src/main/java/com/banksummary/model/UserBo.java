package com.banksummary.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class UserBo {

	private String username;

	private BigDecimal totalbal;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public BigDecimal getTotalbal() {
		return totalbal;
	}

	public void setTotalbal(BigDecimal totalbal) {
		this.totalbal = totalbal;
	}
	
	

}
