package com.banksummary.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banksummary.dao.IBankAccount;
import com.banksummary.dao.IBankuser;
import com.banksummary.entity.Account;
import com.banksummary.entity.User;
import com.banksummary.model.UserBo;

@RestController
public class BankSummaryController {

	@Autowired
	private IBankuser bankUserRepo;

	@Autowired
	private IBankAccount account;
	
	@GetMapping("/getAllUserSummary")
	public List<UserBo> getAllUserSummary() {
		List<UserBo> userList = new ArrayList<UserBo>();
		List<User> user= bankUserRepo.findAll();
		for (User user2 : user) {
			UserBo bo = new UserBo();
			bo.setUsername(user2.getFirstName()+" "+user2.getLastName());
			BigDecimal totalbal = new BigDecimal(0);
			for (Account account : user2.getAccount()) {
				totalbal = totalbal.add(account.getBal());
			}
			bo.setTotalbal(totalbal);
			userList.add(bo);
		}
		return userList;
	}
}
