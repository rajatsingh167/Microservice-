package com.banksummary.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.banksummary.entity.Account;

public interface IBankAccount extends JpaRepository<Account, String> {

}
