package com.banksummary.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.banksummary.entity.User;

public interface IBankuser extends JpaRepository<User, String>{

}
