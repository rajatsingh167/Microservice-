package com.banksummary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankSummaryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
